<?php
$body = [
  'ad_tracking' => 'ebook',
  'custom_fields' => [
    'apple' => 'fuji',
    'pear' => 'bosc'
  ],
  'email' => 'user@example.com',
  'ip_address' => '192.168.0.1',
  'last_followup_message_number_sent' => 0,
  'misc_notes' => 'string',
  'name' => 'John Doe',
  'strict_custom_fields' => 'true',
  'tags' => [
    'slow',
    'fast',
    'lightspeed'
  ]
];
$headers = [
    'Content-Type' => 'application/json',
    'Accept' => 'application/json',
    'User-Agent' => 'AWeber-PHP-code-sample/1.0'
];
$url = "https://api.aweber.com/1.0/accounts/pojhfgvbb/lists/1/subscribers";
$response = $client->post($url, ['json' => $body, 'headers' => $headers]);
echo $response->getHeader('Location')[0];

?>