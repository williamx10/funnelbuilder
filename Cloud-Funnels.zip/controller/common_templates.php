<?php
function funnelSettingsPopup($data_arr=array())
{
	ob_start();
?>

<div class="row">
<div class="col-sm-12">
<span style="float:right;color:rgb(31, 87, 202);font-size:16px;margin-bottom:10px;cursor:pointer;" v-on:click="funnalSettingToggle()"><i class="fas fa-arrow-alt-circle-left"></i> Go&nbsp;back</span>
</div>
</div>
<div class="container-fluid">

		<ul class="nav nav-tabs md-tabs nav-justified theme-nav rounded-top  d-flex flex-column flex-sm-row" role="tablist">


			<li class="nav-item">
				<a class="nav-link active" data-toggle="tab" href="#home" role="tab">
					<i class="fas fa-cog pr-2"></i>Page Settings</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" data-toggle="tab" href="#menu1" role="tab">
					<i class="fas fa-table pr-2"></i>Edit SEO Data</a>
			</li>

		</ul>
	</div>


<div class="container-fluid">
<div class="form-inputs">
<div class="tab-content">	
<div id="home" class="tab-pane fade show active">
					<div class="col-md-12 pl-0"> <label for="url">Page URL:</label>
						<div class="input-group">
							<div class="input-group-prepend"><span class="input-group-text">{{funnel_url}}/</span></div>
							<input type="text" class="form-control" id="quick-url" placeholder="Path" v-model="page_foler_name">
							<div class="input-group-append" data-toggle="tooltip" title="Copy To Clipboard" onclick=copyText('funnel.funnel_url+"/"+funnel.page_foler_name+"/"',1) style="cursor:pointer;"><span class="input-group-text"><i class="fas fa-copy"></i></span></div>
							<div class="input-group-append" data-toggle="tooltip" title="Copy Verified Membership Link" v-if="(tempselected_category=='register')? true:false" style="cursor:pointer;" onclick=copyText('funnel.funnel_url+"/"+funnel.page_foler_name+"@-cf-veried-"+funnel.current_funnel+"-member-@"',1)><span class="input-group-text"><i class="fas fa-user-shield"></i></span></div>
						</div>
					</div>
					
					<div class="row col-md-12 mt-2 ">

						<div class="col-md-4 pt-3 pb-2 bg-white  rounded">
							<div class="custom-control custom-switch mb-2" v-on:click="doInitAbTurnOn()">
								<input type="checkbox" class="custom-control-input " id="customSwitches1" v-model="template_has_a_b_test">
								<label class="custom-control-label" for="customSwitches1">Use A/B Testing</label>
							</div>
							<div class="custom-control custom-switch mb-2" id="gdprhandle">
								<input type="checkbox" class="custom-control-input " id="customSwitch4" v-model="page_settings.cookie_notice">
								<label class="custom-control-label" for="customSwitch4">Display GDPR Cookie Notice</label>
							</div>
							<div class="custom-control custom-switch mb-2" data-toggle="tooltip" title="Its not recomended to use the cache mode for Membership pages and Payment Confirmation Pages but you can use with other category like sales pages, optin generation pages etc according your requirement.">
								<input type="checkbox" class="custom-control-input " id="customSwitchescache" v-model="page_settings.page_cache">
								<label class="custom-control-label" for="customSwitchescache">Create Page Cache</label>
							</div>
							<div class="custom-control custom-switch mb-2" data-toggle="tooltip" title="Cache will be turrened on automatically if you want to create AMP Version for the page.">
								<input type="checkbox" class="custom-control-input " id="customSwitchamp" v-model="page_settings.active_amp" v-on:change="activeCacheForAMP">
								<label class="custom-control-label" for="customSwitchamp">Create Equivalent AMP Page</label>
							</div>
							<div class="custom-control custom-switch mb-2" data-toggle="tooltip" title="<?php if(!get_option('zapier_auth_id')){echo "You can not modify the setting until you create a Zapier authentication token";} ?>">
								<input type="checkbox" class="custom-control-input " id="customSwitchesZapier" v-model="page_settings.zapier_enable" <?php if(!get_option('zapier_auth_id')){echo "disabled=true";} ?>>
								<label class="custom-control-label" for="customSwitchesZapier">Send Leads to Zapier</label>
							</div>
							<div class="custom-control custom-switch" v-if="(selected_template_category=='register')">
								<input type="checkbox" class="custom-control-input " id="customSwitch3" v-model="verifyed_membership_page">
								<label class="custom-control-label" for="customSwitch3">Verified Registration Page</label>
							</div>


							<div class="" id="redirectioncntrol">
								<div class="custom-control custom-switch">
									<input type="checkbox" class="custom-control-input" id="customSwitch2" v-model="page_settings.redirect_for_post">
									<label class="custom-control-label" for="customSwitch2">Redirect Instead Of Going To The Next Page</label>

								</div>
								<label style="margin-top:5px;margin-bottom:2px;">Enter Redirecton URL</label>
								<input type="url" class="form-control form-control-sm" placeholder="Enter URL" v-model="page_settings.redirect_for_post_url">
							</div>
							<div class="form-group nopadding">
								<label for="category" class="mt-2 mb-0">Page Category:</label>
								<select class="form-control form-control-sm mt-0" id="category" v-model="tempselected_category">
									<option value="all">Not Specific</option>
									<option value="optin">Optin</option>
									<option value="register">Register</option>
									<option value="login">Login</option>
									<option value="membership">Membership</option>
									<option value="forgotpassword">Forgot Password</option>
									<option value="sales">Sales</option>
									<option value="orderform">Order Form</option>
									<option value="confirm">Confirmation</option>
									<option value="cancel">Cancelation Page</option>
									<option value="thankyou">Thank You Page</option>
									<option value="tandc">Terms and Conditions</option>
									<option value="privacy_policy">Privacy Policy</option>
									<!--<option value="404">Error 404</option>-->
								</select>
							</div>
							<div class="form-group">
								<label class="mb-0 mt-2">SMTP For The Project</label>
								<select v-model='selected_smtp' class='form-control form-control-sm mt-0'>
									<option value='0'>No Mailer</option>
									<option value='phpmailer'>PHP Mailer</option>
									<?php
										$smtps = $data_arr['smtps'];
										if (is_object($smtps)) {
											if ($smtps->num_rows) {
												$smtps->data_seek(0);
											}
											while ($r = $smtps->fetch_object()) {
												echo "<option value='" . $r->id . "'>" . $r->title . "</option>";
											}
										}
										?>
								</select>
							</div>
							
							<!-- select list -->
							<div class="dropdown mb-2">
								<button class="btn   btn-info btn-block dropdown-toggle mr-4" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Select Lists</button>

								<div class="dropdown-menu" aria-labelledby="dropdownMenuLink" id="listslist">
									<?php
										$lists = $data_arr['lists'];
										if (is_object($lists)) {
											if ($lists->num_rows) {
												$lists->data_seek(0);
											}
											while ($r = $lists->fetch_object()) {
												echo '<div class="form-check pr-5"><input type="checkbox" value="' . $r->id . '" id="labellist"> <label class="form-check-label" for="labellist">' . $r->title . '</label></div>';
											}
										} else {
											echo "<div class='bg-danger text-white m-3 p-3'>No Lists Created</div>";
										}
										?>
								</div>
							</div>
							<!--end select list -->

							<div class="dropdown mb-2">
								<button class="btn btn-info btn-block dropdown-toggle mr-4" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Select Membership Access</button>

								<div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
									<?php
										$regpages = $data_arr['registrationpages'];
										if (count($regpages) > 0) {
											foreach ($regpages as $regindex => $regvalue) {
												echo '<div class="form-check pr-5"><input type="checkbox" value="' . $regindex . '" v-model="selected_membership_pages"> <label class="pl-3">' . $regvalue . '</label></div>';
											}
										} else {
											echo "<div class='bg-danger text-white m-3 p-3'>No Registration Page Created For Members</div>";
										}
										?>
								</div>
							</div>
							<!-- End MEmbership access -->
							<!-- Select Autoresponders-->
							<div class="dropdown mb-2">
								<button class="btn btn-info btn-block dropdown-toggle mr-4" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Select Autoresponders</button>
								<div class="dropdown-menu" aria-labelledby="dropdownMenuLink" id="autoreslist">
									<?php
										$allautoresponders = $data_arr['autoresponders'];
										$autorespondercount = 0;
										if (is_object($allautoresponders)) {
											if ($allautoresponders->num_rows) {
												$allautoresponders->data_seek(0);
											}
											if ($allautoresponders) {
												while ($r = $allautoresponders->fetch_object()) {
													++$autorespondercount;
													echo '<div class="form-check"><input class="mr-2" type="checkbox" id="check-responder" value="' . $r->id . '"><label class="form-check-label justify-content-center" for="check-responder">' . $r->autoresponder . '</label></div>';
												}
											}
										}
										if ($autorespondercount < 1) {
											echo "<div class='bg-danger text-white m-3 p-3'><strong>No Autoresponders Added</strong></div>";
										}
										?>
								</div>
							</div>
							<!--End  Select Autoresponders-->
							<div class="dropdown mb-2">
								<button class="btn btn-info btn-block dropdown-toggle mr-4" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Select Integrations</button>

								<div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
									<?php
										$integrations_ob = $data_arr['integrations'];
										$integrations = $integrations_ob->getData('all');
										if($integrations->num_rows<1)
										{
											echo "<div class='bg-danger text-white m-3 p-3'>No Integrations Created</div>";
										}
										while ($r = $integrations->fetch_object()) {
											echo '<div class="form-check pr-5"><input type="checkbox" value=' . $r->id . ' v-model="page_settings.snippet_integrations"> <label>' . $r->title . '</label></div>';
										}
										?>
								</div>
							</div>

							<!-- PaymentMtehod -->
							<div class="dropdown mb-2" v-if="(selected_template_category=='orderform')">
								<button class="btn btn-info dropdown-toggle btn-block mr-4" data-target="#paymentmethods" data-toggle="collapse">Select Payment Methods</button>
								<div id="paymentmethods" class="collapse">

									<?php
										$ipnpaymenturl = get_option('install_url');
										$ipnpaymenturl = "'" . $ipnpaymenturl . "/index.php?page=do_payment&execute=1&qfnl_is_ipn=" . get_option('ipn_token');
										$ipnpaymenturl .= "&qfunnel_id='+current_funnel+'&qfolder='+page_foler_name"
										?>

									<?php
										$paymentmethods = $data_arr['paymentmethods'];
										if (is_object($paymentmethods)) {
											if ($paymentmethods->num_rows) {
												$paymentmethods->data_seek(0);
											}
											while ($r = $paymentmethods->fetch_object()) {
												if (strpos($r->method, "_ipn") > 0) {
													echo '<div class="input-group" style="margin-top:1px;margin-bottom:1px"><div class="input-group-prepend"><span class="input-group-text"><input type="radio" value="' . $r->id . '" name="" v-model="selected_payment_method"> ' . $r->title . ' (IPN)</span></div><input type="text" class="form-control" v-bind:value="' . $ipnpaymenturl . '" onclick="copyText(this.value)" data-toggle="tooltip" title="Copy To Clipboard"></div>';
												} else {
													echo '<div class="input-group" style="margin-top:1px;margin-bottom:1px"><div class="input-group-prepend"><span class="input-group-text"><input type="radio" value="' . $r->id . '" name="" v-model="selected_payment_method"></span></div><p class="form-control"> ' . $r->title . '</p></div>';
												}
											}
										} else {
											echo "<div class='bg-danger text-white m-3 p-3'>No Payment Methods Created</div>";
										}
										?>
								</div>
							</div>
							<!--End PaymentMtehod -->

							<!-- Select Product -->
							<div class="dropdown mb-2" v-if="(selected_template_category=='orderform')">
								<button class="btn btn-info dropdown-toggle btn-block mr-4" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Select Product</button>
								<div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
									<?php
										$products = $data_arr['products'];
										if (is_object($products)) {
											if ($products->num_rows) {
												$products->data_seek(0);
											}
											while ($r = $products->fetch_object()) {
												echo '<div class="form-check"><input type="radio" value="' . $r->id . '" name="" v-model="selected_product"><label>(#' . $r->productid . ') ' . $r->title . '</label></div>';
											}
										} else {
											echo "<div class='bg-danger text-white m-3 p-3'>No Products Created</div>";
										}
										?>
								</div>
							</div>
							<!--End Select Product-->
						</div>
				
						<!-- end col-md-4 -->




						<div class="col-md-8 row script mt-2 ml-auto">
							<div class="col-md-6 ">
								<div class="form-group">
									<label for="header">Header Script:</label>
									<textarea class="form-control" id="quick-header" rows="8" placeholder="Enter Header Script" v-model="page_header_scripts"></textarea>
								</div>
								<div class="form-group">
									<label for="footer">Footer Script:</label>
									<textarea class="form-control" id="quick-footer" rows="8" placeholder="Enter Footer Script" v-model="page_footer_scripts"></textarea>
								</div>
								</div>
								<div class="col-md-6 ">
								<div class="form-group">
									<label for="footer">Valid Input Names For The Project:</label>
									<textarea class="form-control" id="quick-footer" rows="8" placeholder="Enter Input Names. Please Enter One On Each Line" v-bind:value="common_inputs_for_current_funnel.split(',').join('\n')" v-on:change="addFunnelAndPageValidInput('common_inputs_for_current_funnel',$event)"></textarea>
								</div>
								<div class="form-group">
									<label for="footer">Valid Input Names For This Page:</label>
									<textarea class="form-control" id="quick-footer" rows="8" placeholder="Enter Input Names. Please Enter One On Each Line" v-bind:value="valid_inputs_pages.split(',').join('\n')" v-on:change="addFunnelAndPageValidInput('valid_inputs_pages',$event)"></textarea>
								</div>
							
							</div>
							
								
								
						</div>


					
						

					</div>






				</div>


				<!-- end first tab -->
				<!-- start second tab -->
				<div id="menu1" class="tab-pane fade " id="seodatas">

					<!-- seo datas -->
					<div class="row mt-4">
						<div class="col-md-6">

							<div class="form-group">

								<label for="title">Page Title:</label>
								<input type="text" class="form-control" id="quick-title" placeholder="Enter Title" v-model="page_title">
							</div>

						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Title Icon</label>
								<input type="text" class="form-control" id="quick-icon" placeholder="Enter Icon URL" v-model="page_meta.icon">
							</div>
						</div>


					</div>

					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Page Description</label>
								<textarea class="form-control" rows="4" placeholder="Enter Description" v-model="page_meta.description"></textarea>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Keywords</label>
								<textarea class="form-control" rows="4" placeholder="Add Keywords. Please Enter One On Each Line" v-bind:value="page_meta.keywords.split(',').join('\n')" v-on:change="addFunnelAndPageValidInput('page_meta.keywords',$event)"></textarea>
							</div>
						</div>
					</div>



					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Robots Value</label>
								<textarea class="form-control" rows="4" placeholder="Enter Robots Data" v-model="page_meta.robots"></textarea>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Copyright</label>
								<textarea class="form-control" rows="4" placeholder="Enter Copyright Description" v-model="page_meta.copyright"></textarea>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="title">DC.title</label>
						<textarea class="form-control" placeholder="Add DC.title" v-model="page_meta.DC_title"></textarea>
					</div>



				</div>
</div>
</div>


<button type="button" class="btn theme-button btntosavepagesetting" v-on:click="updatecurrentfunnelsetting()" style="color:white;margin-top:10px;">Save Settings</button>
<span style="margin-left:10px;" v-bind:style="{color:(funnel_setting_err.indexOf('success')>=0)? 'green':'#ff0066'}">
<strong>{{funnel_setting_err}}</strong>
</span>

<setting_toggle></setting_toggle>
</div>

<?php
$contents=ob_get_contents();
ob_end_clean();
return $contents;
} 
?>
