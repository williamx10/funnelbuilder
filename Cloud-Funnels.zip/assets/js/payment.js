var request=new ajaxRequest();
var payments=new Vue(
{  
	el:"#vuepayment",
	data:{
		payid:"",payname:"",
		baserow:true,err:"",
		paypal:false,pclient_id:"",pclient_secret:"",ptitle:"",ptax:"0",
		stripe:false,sclient_id:"",sclient_secret:"",stitle:"",stax:"0",
		authorizenet:false,aclient_id:"",aclient_secret:"",atitle:"",atax:"0",
		jvzoo_ipn:false,ititle:"",iclient_id:"N/A",iclient_secret:"",itax:"N/A",
		warriorplus_ipn:false,paykickstart_ipn:false,paydotcom_ipn:false,
		thrivecart_ipn:false,clickbank_ipn:false,
	}, 
	mounted:function(){
	 	document.onreadystatechange = () => { 
    if (document.readyState == "complete") {
		document.getElementById("editformcontainer").style.display="block";  
        this.editrecords();
    }
}
  }, 
	methods:{
		editrecords:function(){
			this.err="";
			var thisvue=this;
			if(document.getElementById('payname') && document.getElementById('payname').value){
		this.payname = document.getElementById('payname').value;
		if (this.payname == "paypal") {
		this.payid = document.getElementById('payid').value;
		this.ptitle = document.getElementById('paytitle').value;
		this.pclient_id = document.getElementById('payclientid').value;
        this.pclient_secret = document.getElementById('payclientsec').value;
        this.ptax = document.getElementById('paytax').value;
		this.paypal=true;
		}
		else if(this.payname == "stripe"){
		this.payid = document.getElementById('payid').value;
		this.stitle = document.getElementById('paytitle').value;
		this.sclient_id = document.getElementById('payclientid').value;
        this.sclient_secret = document.getElementById('payclientsec').value;
        this.stax = document.getElementById('paytax').value;
		this.stripe=true;
		}
		else if(this.payname == "authorize.net"){
		this.payid = document.getElementById('payid').value;
		this.atitle = document.getElementById('paytitle').value;
		this.aclient_id = document.getElementById('payclientid').value;
        this.aclient_secret = document.getElementById('payclientsec').value;
        this.atax = document.getElementById('paytax').value;
		this.authorizenet=true;
		}
		else if(this.payname=="jvzoo_ipn")
		{
		this.payid = document.getElementById('payid').value;	
	   	this.ititle = document.getElementById('paytitle').value;	
		this.iclient_secret = document.getElementById('payclientsec').value;	
        this.jvzoo_ipn=true;
		}
		else if(this.payname=="warriorplus_ipn")
		{
		this.payid = document.getElementById('payid').value;	
		this.ititle = document.getElementById('paytitle').value;	
		this.iclient_secret = document.getElementById('payclientsec').value;	
        this.warriorplus_ipn=true;
		}
		else if(this.payname=="paykickstart_ipn")
		{
		this.payid = document.getElementById('payid').value;	
		this.ititle = document.getElementById('paytitle').value;		
		this.iclient_secret = document.getElementById('payclientsec').value;	
        this.paykickstart_ipn=true;
		}
		else if(this.payname=="paydotcom_ipn")
		{
		this.payid = document.getElementById('payid').value;	
		this.ititle = document.getElementById('paytitle').value;			
		this.iclient_secret = document.getElementById('payclientsec').value;	
        this.paydotcom_ipn=true;
		}
		else if(this.payname=="thrivecart_ipn")
		{
		this.payid = document.getElementById('payid').value;	
		this.ititle = document.getElementById('paytitle').value;			
		this.iclient_secret = document.getElementById('payclientsec').value;	
        this.thrivecart_ipn=true;
		}
		else if(this.payname=="clickbank_ipn")
		{
		this.payid = document.getElementById('payid').value;	
		this.ititle = document.getElementById('paytitle').value;			
		this.iclient_secret = document.getElementById('payclientsec').value;	
        this.clickbank_ipn=true;
		}
		try{
			doEscapePopup(function(){thisvue.closeForm(thisvue.payname);});
		}catch(err){}
	}
		},
		showForm:function(paymenttype){
		// this.mainblock=true;
		this.err="";
		var thisvue=this;
		if (paymenttype == "paypal") {
			this.paypal=true;
			this.stripe=false;
			this.authorizenet=false;
			this.warriorplus_ipn=false;this.paykickstart_ipn=false;this.paydotcom_ipn=false;
			this.jvzoo_ipn=false;
		}
		else if (paymenttype == "stripe") {
			this.stripe = true;
			this.paypal = false;
			this.authorizenet = false;
			this.warriorplus_ipn=false;this.paykickstart_ipn=false;this.paydotcom_ipn=false;
			this.jvzoo_ipn=false;
		}
		else if (paymenttype == "authorizenet") {
			this.authorizenet = true;
			this.paypal = false;
			this.stripe = false;
			this.warriorplus_ipn=false;this.paykickstart_ipn=false;this.paydotcom_ipn=false;
			this.jvzoo_ipn=false;this.thrivecart_ipn=false;this.clickbank_ipn=false;
		}
		else if (paymenttype == "jvzoo_ipn") {
			this.authorizenet = false;
			this.paypal = false;
			this.stripe = false;
			this.warriorplus_ipn=false;this.paykickstart_ipn=false;this.paydotcom_ipn=false;
			this.jvzoo_ipn=true;this.thrivecart_ipn=false;this.clickbank_ipn=false;
		}
		else if (paymenttype == "warriorplus_ipn") {
			this.authorizenet = false;
			this.paypal = false;
			this.stripe = false;
			this.warriorplus_ipn=true;this.paykickstart_ipn=false;this.paydotcom_ipn=false;
			this.jvzoo_ipn=false;this.thrivecart_ipn=false;this.clickbank_ipn=false;
		}
		else if (paymenttype == "paykickstart_ipn") {
			this.authorizenet = false;
			this.paypal = false;
			this.stripe = false;
			this.warriorplus_ipn=false;this.paykickstart_ipn=true;this.paydotcom_ipn=false;
			this.jvzoo_ipn=false;this.thrivecart_ipn=false;this.clickbank_ipn=false;
		}
		else if (paymenttype == "paydotcom_ipn") 
		{
			this.authorizenet = false;
			this.paypal = false;
			this.stripe = false;
			this.warriorplus_ipn=false;this.paykickstart_ipn=false;this.paydotcom_ipn=true;
			this.jvzoo_ipn=false;this.thrivecart_ipn=false;this.clickbank_ipn=false;
		}
		else if (paymenttype == "thrivecart_ipn") 
		{
			this.authorizenet = false;
			this.paypal = false;
			this.stripe = false;
			this.warriorplus_ipn=false;this.paykickstart_ipn=false;this.paydotcom_ipn=false;
			this.jvzoo_ipn=false;this.thrivecart_ipn=true;this.clickbank_ipn=false;
		}
		else if (paymenttype == "clickbank_ipn") 
		{
			this.authorizenet = false;
			this.paypal = false;
			this.stripe = false;
			this.warriorplus_ipn=false;this.paykickstart_ipn=false;this.paydotcom_ipn=false;
			this.jvzoo_ipn=false;this.thrivecart_ipn=false;this.clickbank_ipn=true;
		}
		
		try{
			doEscapePopup(function(){thisvue.closeForm(paymenttype);});
		}catch(err){}
	},
	closeForm:function(type){
		if (type == "paypal") {
			this.paypal=false;
		}
		else if(type == "stripe"){
			this.stripe=false;
		}
		else if(type == "authorizenet"){
			this.authorizenet=false;
		}
		else if(type == "jvzoo_ipn"){
			this.jvzoo_ipn=false;
		}
		else if(type == "warriorplus_ipn"){
			this.warriorplus_ipn=false;
		}
		else if(type == "paykickstart_ipn"){
			this.paykickstart_ipn=false;
		}
		else if(type == "paydotcom_ipn"){
			this.paydotcom_ipn=false;
		}
		else if(type == "thrivecart_ipn"){
			this.thrivecart_ipn=false;
		}
		else if(type=="clickbank_ipn")
		{
			this.clickbank_ipn=false;
		}
	},
	saveIPN:function(type){
		try
		{
		thisvue=this;
		if(this.ititle.trim().length>1)
		{
			var sdata={"payment":1,"paymenttype":type,"title":this.ititle,"clientid":this.iclient_id,"clientsecret":this.iclient_secret,"tax":this.itax,"payid":this.payid};
			request.postRequestCb('req.php',sdata,function(data){
				if(data.trim()=='1')
				{
					thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: rgb(72, 161, 79);'>Records Saved Successfully.</center></p>";
					setTimeout(function(){
					thisvue[type]=false;},500);
				}
				else
				{
					thisvue.err=data.trim();
				}
			});
		}
		else
		{
			this.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Please Fill All Details</center></p>";
		}
		}
		catch(errr){this.err=errr.message;}
	},
	savepaypal:function(){
		if (this.pclient_id.length>0 && this.pclient_secret.length>0 && this.ptitle.length>0 && this.ptax.length>0) {
		var thisvue=this;
		this.err="";
		var data={"payment":1,"paymenttype":"paypal","title":this.ptitle,"clientid":this.pclient_id,"clientsecret":this.pclient_secret,"tax":this.ptax,"payid":this.payid};
		request.postRequestCb('req.php',data,function(result){
			// alert(result);
			if(result.trim() == '1')
				{
					thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: rgb(72, 161, 79);'>Records Saved Successfully.</center></p>";
					setTimeout(function(){thisvue.paypal=false;},500);
				}
			    else
				{
					thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Record Already Exists.</center></p>";
				}
		});
		}
		else{   
			this.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Please Fill All Details.</center></p>";
		}
	},
	savestripe:function(){
		if (this.sclient_id.length>0 && this.sclient_secret.length>0 && this.stitle.length>0) {
		var thisvue=this;
		this.err="";
		var data={"payment":1,"paymenttype":"stripe","title":this.stitle,"clientid":this.sclient_id,"clientsecret":this.sclient_secret,"tax":this.stax,"payid":this.payid};
		request.postRequestCb('req.php',data,function(result){
			// alert(result);
			if(result.trim() == '1')
				{
					thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: rgb(72, 161, 79);'>Records Saved Successfully.</center></p>";
					setTimeout(function(){thisvue.stripe=false;},500);
				}
			    else
				{
					thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Record Already Exists.</center></p>";
				}
		});
		}
		else{   
			this.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Please Fill All Details.</center></p>";
		}
	},
	saveauthorizenet:function(){
		if (this.aclient_id.length>0 && this.aclient_secret.length>0 && this.atitle.length>0) {
		var thisvue=this;
		this.err="";
		var data={"payment":1,"paymenttype":"authorize.net","title":this.atitle,"clientid":this.aclient_id,"clientsecret":this.aclient_secret,"tax":this.atax,"payid":this.payid};
		request.postRequestCb('req.php',data,function(result){
			// alert(result);
			if(result.trim() == '1')
				{
					thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: rgb(72, 161, 79);'>Records Saved Successfully.</center></p>";
					setTimeout(function(){thisvue.authorizenet=false;},500);
				}
			    else
				{
					thisvue.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Record Already Exists.</center></p>";
				}
		});
		}
		else{   
			this.err="<p><center style='margin: -17px 0px -8px 0px;color: red;'>Please Fill All Details.</center></p>";
		}
	},

}
});